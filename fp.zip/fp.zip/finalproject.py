import csv
import matplotlib.pyplot as plt


def avg_number_goal(filename):
    """
    takes in a file name and creates a dictionary with the jersey number as a key and the average amount of
    goals that jersey scored. does so by creating two dictionaries, the values of the two being total goals scored for a
    particular jersey and the number of players with that jersey.
    :param filename: file containing information on every English Premier League player
    :return: (dict) dictionary with jersey number and average goal
    """

    # turn file so it is csv readable
    file = open(filename, "r")
    csv_file = csv.reader(file)

    counter = 0
    jersey_goal = {}
    total_jersey = {}

    # for each player, check their jersey number and add their amount of goals to the dictionary
    for line in csv_file:

        # skip first line that does not have any player info
        if counter != 0:
            # line[1] is jersey number and line[6] is amount of goals. Those create jersey_goal
            if int(line[1]) in jersey_goal.keys():
                jersey_goal[int(line[1])] = jersey_goal[int(line[1])] + int(line[6])
            else:
                jersey_goal[int(line[1])] = int(line[6])

            # counts the number of players that have the same number using a dictionary total_jersey
            if int(line[1]) in total_jersey.keys():
                total_jersey[int(line[1])] += 1
            else:
                total_jersey[int(line[1])] = 1

        counter += 1

    # since the sizes of jersey_goal and total_jersey are the same, this loops through the dictionary and finds the
    # average amount of goals scored by each jersey
    for i in jersey_goal:
        jersey_goal[i] = jersey_goal[i] / total_jersey[i]

    # sort the keys (jerseys) in jersey_goal in numerical order
    sorted_jersey_goal = dict(sorted(jersey_goal.items()))

    file.close()

    return sorted_jersey_goal


def most_goals(jersey_dict):
    """
    returns a list with the most goals scored by a certain jersey number
    :param jersey_dict: (dict) created by function avg_number_goal
    :return: (list) that has jersey number and highest average goals scored
    """

    goal_list = []
    # most average goals scored
    max_goal = max(jersey_dict.values())

    # for each value, if the max_goal matches the key, create a new dictionary
    for i in jersey_dict:
        if jersey_dict[i] == max_goal:
            goal_list.append(i)
            goal_list.append(max_goal)

    return goal_list


def plot_goal(dict, format):
    """
    Plots dict as a plot with x-axis being jersey numbers and y-axis being goals
    :param dict: (dict) with keys and values of jersey numbers and average goals
    :param format: (str) the style, including color and shape, of the points on the plot
    :return: None
    """

    x_list = []
    y_list = []

    # for all the data, append to the x and y lists the corresponding information from data
    for i in dict:
        x_list.append(i)
        y_list.append(dict[i])

    # plot points
    plt.plot(x_list, y_list, format, label="average goal scored")

    # plot details
    plt.legend()
    plt.xlabel("Jersey Number")
    plt.ylabel("Number of Goals")
    plt.title("Average Goals Scored by Jersey Number")
    plt.savefig("visualization1.png")


def point_total(filename, team):
    """
    for each match result, add to a dictionary with keys of number of games played and values of the points the team has
    :param filename: (file) containing all the match results from the English Premier League last season
    :param team: (str) of any team, but here it will be "Manchester United"
    :return: (dict) dictionary with matches played and points
    """

    # file opening and variables and dictionary
    file = open(filename, "r")
    csv_file = csv.reader(file)
    date_point_dict = {0: 0}
    point_counter = 0
    matchday_counter = 0

    for match in csv_file:

        # filter data that includes just the team
        if team in match:
            matchday_counter += 1
            # calls helper function that determines how many points were gained that match day
            point_counter += point_per_game(match, team)
            # makes entries of a dictionary
            date_point_dict[matchday_counter] = point_counter

    file.close()

    return date_point_dict


def point_per_game(list, team):
    """
    Looks at match results by comparing the scores and determines how many points should be given to the team
    (a win is 3 points, a tie is 1 point, and a loss is 0 points)
    :param list: (list) containing data of a team and its opponent and the score between them
    :param team: desired results from a team
    :return: (int) the number of points gained from a game
    """

    # integer that will be added the points from the result of the game
    point_counter = 0

    # the scores are divided by the colon, so assign the two team's scores by splitting on ":"
    (home_score, away_score) = list[2].split(":")

    # if the home_score is greater than the away_score and home is the desired team, than that means the team won and
    # thus 3 points. If home_team won, but they're not home, that is 0 points and thus no need to chane point_counter
    # If they're equal the teams tied, so 1 point. The same principal works when away_team scores more but flipped.
    if home_score > away_score:
        # when team is home. format states home team first
        if list[1] == team:
            point_counter += 3
    elif home_score == away_score:
        point_counter += 1
    else:
        # when team is away
        if not list[1] == team:
            point_counter += 3

    return point_counter


def plot_points(dict, format):
    """
    Plots dict as a plot with x-axis being number of games (0 - 38) and y-axis being amount of points
    :param dict: (dict) with keys and values of number of games and points
    :param format: (str) the style, including color and shape, of the points on the plot
    :return: None
    """
    x_list = []
    y_list = []

    # for all the data, append to the x and y lists the corresponding information from data
    for i in dict:
        x_list.append(i)
        y_list.append(dict[i])

    # plot points: first plot is a progression line and second plot is dots for each game
    plt.plot(x_list, y_list)
    plt.plot(x_list, y_list, format, label="matchday")

    # plot details
    plt.legend()
    plt.xlabel("Matchday")
    plt.ylabel("Total Points")
    plt.title("Point progression")
    plt.savefig("visualization2.png")

    # total points
    point = "total points = " + str(dict[38])
    return point


def count_cards(filename, card_type, both):
    """
    Counts the amount of cards (card type depending on parameter, card_type) each player received. Creates a dictionary
    with the key being the team name and value being the amount of cards
    :param filename: (file) of all players that track card data
    :param card_type: (int) index of the card type. Yellow card is index 7 in the list of information and red is 8
    :param both: (bool) when True, counts both red and yellow cards, if not, just one of the two cards
    :return: (dict) key: team name, value: number of cards
    """

    # file opening and variables and dictionary
    file = open(filename, "r")
    csv_file = csv.reader(file)
    card_dict = {}
    counter = 0

    # If both is not True, this is counting just either yellow cards or red cards
    if not both:

        # for each player, adds to a dictionary with the key of team name and value of amount of cards received
        for line in csv_file:

            # skip first line because it is not a player
            if counter != 0:
                if line[0] in card_dict.keys():
                    card_dict[line[0]] += float(line[card_type])
                else:
                    card_dict[line[0]] = float(line[card_type])
            counter += 1

    # This is counting both red and yellow cards
    else:
        for line in csv_file:

            if counter != 0:
                if line[0] in card_dict.keys():
                    card_dict[line[0]] += float(line[card_type]) + float(line[card_type + 1])
                else:
                    card_dict[line[0]] = float(line[card_type]) + float(line[card_type + 1])
            counter += 1

    # convert to integers
    for team in card_dict:
        card_dict[team] = int(card_dict[team])

    file.close()

    return card_dict


def most_cards(dict):
    """
    creates a new dictionary that has the top three teams with the most cards
    :param dict: dictionary created by return value of function, count_cards
    :return: (dict) with key of team name and value of amount of cards
    """

    top_three_cards = {}
    card_list = []
    team_name = list(dict)
    card_amount = list(dict.values())

    # convert to list that still has the same order as the dict. this is for indexing and finding the max
    for team in range(len(dict)):
        card_list.append(team_name[team])
        card_list.append(card_amount[team])

    # finds the maximum number, representing the most amount of a card received by a team, and uses indexing to take the
    # amount of cards and the team name and puts it into a dictionary
    for _ in range(3):
        max_card = max(card_amount)
        card_index = card_list.index(max_card)
        team_index = card_index - 1
        top_three_cards[card_list[team_index]] = card_list[card_index]

        # delete the key and value so function can find the new maximum
        del (card_list[card_index])
        del (card_list[team_index])
        del (card_amount[card_amount.index(max_card)])

    return top_three_cards


def plot_cards(dict_one, dict_two, dict_three):
    """
    Plots three dictionaries with x-axis being team name and y-axis being amount of cards received
    :param dict_one: (dict) created by function most_cards for yellow cards
    :param dict_two: (dict) created by function most_cards for red cards
    :param dict_three: (dict) created by function most_cards for yellow and red cards
    :return: None
    """

    # for each of the three dictionaries: plot the team name on x-axis and amount of cards on y-axis
    for i in range(3):
        y_list = []
        if i == 0:
            bar_color = 'y'
            legend_card = ["yellow"]
            x_list = ["1", "2", "3"]
            for x in dict_one:
                y_list.append(dict_one[x])

        elif i == 1:
            bar_color = "r"
            legend_card.append("red")
            x_list = ["4", "5", "6"]
            for y in dict_two:
                y_list.append(dict_two[y])

        else:
            bar_color = "k"
            legend_card.append("both")
            x_list = ["7", "8", "9"]
            for j in dict_three:
                y_list.append(dict_three[j])

        # plot points
        plt.bar(x_list, y_list, color=bar_color, width=0.9)

    # plot details
    plt.legend(legend_card)
    plt.xlabel("Team")
    plt.ylabel("Total Amount of Cards")
    plt.title("Most Amount of Cards")
    plt.savefig("visualization3.png")


def main():
    """
    prints the numerical values and plots the visualizations for the three questions
    :return: none
    """
    # Question1:
    # get dictionary from avg_number_goal, where the jersey number and the amount of goals are determined
    x = avg_number_goal("all_players_stats.csv")
    y = most_goals(x)

    print("Question 1: What is the jersey number that scores the most amount of goals on average?")
    print("\tThe highest average of goals scored was " + str(y[1]) + " goals by the jersey number " + str(y[0]))

    plot_goal(x, "r+")
    plt.figure()

    # Question 2:
    # get dictionary from point_total and find the total points the team had at end of the season
    w = point_total("all_match_results.csv", "Manchester United")
    final_point = (w[len(w) - 1])

    print("Question 2: How did the point total for my favorite team, Manchester United, change over the season?")
    print("\tMy team, Manchester United, finished with " + str(final_point) + " points")

    plot_points(w, "bo")
    plt.figure()

    # Question 3:
    # get dictionary of length 3 from most_cards which was found through count_cards
    # the second parameter is the card type, 8 being yellow and 9 being red. The bool is indicating counting one
    # card or both red and yellow cards
    most_yellow = most_cards(count_cards("all_players_stats.csv", 8, False))
    most_red = most_cards(count_cards("all_players_stats.csv", 9, False))
    most_both = most_cards(count_cards("all_players_stats.csv", 8, True))

    # convert into list for simple indexing
    yellow_list = list(most_yellow.items())
    red_list = list(most_red.items())
    both_list = list(most_both.items())

    print("Question 3: Which 3 teams received the most yellow, red cards, and both cards?")
    print("\tThe 3 teams that received the most yellow cards are " + yellow_list[0][0] + " and " + yellow_list[1][0]
          + " and " + yellow_list[2][0] + " with " + str(yellow_list[0][1]) + " and " + str(yellow_list[1][1]) + " and "
          + str(yellow_list[2][1]) + " yellow cards")
    print("\tThe 3 teams that received the most red cards are " + red_list[0][0] + " and " + red_list[1][0] + " and " +
          red_list[2][0] + " with " + str(red_list[0][1]) + " and " + str(red_list[1][1]) + " and " +
          str(red_list[2][1]) + " red cards")
    print("\tThe 3 teams that received the most cards are " + both_list[0][0] + " and " + both_list[1][0] + " and " +
          both_list[2][0] + " with " + str(both_list[0][1]) + " and " + str(both_list[1][1]) + " and " +
          str(both_list[2][1]) + " cards")

    # plot legend
    print("\nCard plot legend:")
    print("1 = " + yellow_list[0][0] + " : " + str(yellow_list[0][1]) + ", 2 = " + yellow_list[1][0] + " : " +
          str(yellow_list[1][1]) + ", 3 = " + yellow_list[2][0] + " : " + str(yellow_list[2][1]) + ", 4 = " +
          red_list[0][0] + " : " + str(red_list[0][1]) + ", 5 = " + red_list[1][0] + " : " + str(red_list[1][1]) +
          ", 6 = " + red_list[2][0] + " : " + str(red_list[2][1]) + ", 7 = " + both_list[0][0] + " : " +
          str(both_list[0][1]) + ", 8 = " + both_list[1][0] + " : " + str(both_list[1][1]) + ", 9 = " + both_list[2][0]
          + " : " + str(both_list[2][1]))

    plot_cards(most_yellow, most_red, most_both)


if __name__ == "__main__":
    main()
